#include "test.hpp"
#include "camera/orthogonalCamera.hpp"
#include "camera/perspectiveCamera.hpp"
#include "light/pointLight.hpp"

int main() {
	
	// PREPARE PRIMITIVES
	std::vector<Primitive*> primitives;
	Primitive* p1 = new Sphere(Vector3(1.3f, 0, 8), 1.5f, Material(Vector3(.2f, .4f, .75f)));
	Primitive* p2 = new Sphere(Vector3(-1.0f, 0.5f, 10), 1.f, Material(Vector3(.8f, .1f, .45f)));
	Primitive* p3 = new Sphere(Vector3(-0.8f, -1.f, 16), 2.5f, Material(Vector3(.0f, .9f, .5f)));
	//Primitive* plane1 = new Plane(Vector3(0.f,0.f,1.f), 10.f, Material(Vector3(.9f, .0f, .75f)));
	primitives.push_back(p1);
	primitives.push_back(p2);
	primitives.push_back(p3);
	//primitives.push_back(plane1);

	// PREPARE LIGHTS
	std::vector<LightSource*> lights;
	LightSource* l1 = new PointLight(Vector3(-0.5f, 1.8f, 4.5), Vector3(1, 1, 1), 3.f);
	lights.push_back(l1);

	// RENDER ORTHOGONAL
	//OrthogonalCamera camera(Vector3(0, 0, 0), Vector3(0, 0, 1), 500, 500);
	//camera.renderScene(primitives);

	// RENDER PERSPECTIVE
	PerspectiveCamera camera(Vector3(0, 0, 0), Vector3(0, 0, 1), 500, 500, 60);
	camera.renderScene(primitives, lights, true);

	// DELETE ALLOCATED PRIMITIVES
	for (Primitive* p : primitives) {
		delete p;
	}

	// DELETE ALLOCATED LIGHTS
	for (LightSource* l : lights) {
		delete l;
	}
}